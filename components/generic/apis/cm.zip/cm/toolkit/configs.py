# -*- coding: utf-8 -*-
from esb.utils import SmartHost


SYSTEM_NAME = 'CM'

host = SmartHost(
    host_prod='paas.bk.com',
    host_test='',
)
